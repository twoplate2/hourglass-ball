"""Independent read-only review of recorded video pixels, retaining true PTS."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import sys,json,hashlib,math
import av
import numpy as np
from PIL import Image,ImageDraw

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'src/tools'))
from release_decision import source_digest
from check_stream_motion_shape import displacement,longest_run

BASE=ROOT/'_temp/revision-3.8'
OUT=BASE/'motion-review'
EXPECTED='c59cc24f3bafb1a25ffc08bf0d15a0b900a076a131f86f217d925f75b7fff5b3'
assert source_digest()==EXPECTED

def board(name,items,crop=None,cols=6,thumb=None):
    images=[]
    for label,pixels in items:
        im=Image.fromarray(pixels)
        if crop:im=im.crop(crop)
        if thumb:im.thumbnail(thumb)
        images.append((label,im))
    width=max(im.width for _,im in images);height=max(im.height for _,im in images)
    canvas=Image.new('RGB',(cols*width,math.ceil(len(images)/cols)*(height+22)),(255,255,255))
    d=ImageDraw.Draw(canvas)
    for i,(label,im) in enumerate(images):
        x=i%cols*width;y=i//cols*(height+22)
        canvas.paste(im,(x,y+22));d.text((x+2,y+3),label,fill='black')
    canvas.save(OUT/name)

results={}
for arm in ('video-p5','video-p50'):
    folder=BASE/arm;r=json.loads((folder/'audit.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((folder/'audit.mp4').read_bytes()).hexdigest()==r['sha256']
    rows=r['frames'];g=r['geometry'];cx=g['cx'];half=g['neck_width']/2;outlet=g['outlet_y']
    period=r['period'];pause=r['pause_at'];resume=pause+r['pause_length']
    first_land=next((i for i,f in enumerate(rows) if f['transfer']['landed']>1e-8),None)
    first_grain=next((i for i,f in enumerate(rows) if f['particles']>0),None)
    last_percent=next(i for i,f in enumerate(rows) if f['elapsed']>=.99*period)
    zero=next(i for i,f in enumerate(rows) if f['elapsed']>=period-1e-9)
    pauses=[i for i,f in enumerate(rows) if not f['running'] and f['elapsed']<period]
    summary_times=([0,.3,.6,1,1.4,2,2.5,4,4.65,4.85,5.25,5.4,5.45,5.5,5.7,6]
                   if period==5 else [0,.3,.6,1,1.4,2,5,8,15,25,40,46.8,47.2,48.8,49.2,51.3,51.5,51.8,52.05,52.3,53,56])
    selected={min(range(len(rows)),key=lambda i:abs(rows[i]['time']-t)) for t in summary_times}
    segments={
        'front':list(range(max(0,first_grain),min(len(rows),first_grain+24))),
        'landing':list(range(max(0,first_land-6),min(len(rows),first_land+12))),
        'last-percent':list(range(max(0,last_percent-4),min(len(rows),last_percent+14))),
        'zero-tail':list(range(max(0,zero-4),min(len(rows),zero+14))),
        'resume':list(range(max(0,pauses[-1]-4),min(len(rows),pauses[-1]+14))),
    }
    selected.update(i for seq in segments.values() for i in seq)
    saved={};motions=[];fronts=[];shape=[];contacts=[];pts_errors=[];previous=None;previous_row=None
    decoded_paused=[];last_pause_image=None;paused_max_delta=0
    count=0
    with av.open(str(folder/'audit.mp4')) as movie:
        for i,vf in enumerate(movie.decode(video=0)):
            if i>=len(rows):raise RuntimeError('Unexpected extra decoded frame')
            f=rows[i];a=vf.to_ndarray(format='rgb24')
            pts=float(vf.pts*vf.time_base);pts_errors.append(abs(pts-f['time']))
            if i in selected:saved[i]=a.copy()
            gold=(a[:,:,0].astype(int)>a[:,:,1].astype(int)+15)&(a[:,:,1].astype(int)>a[:,:,2].astype(int)+25)&(a[:,:,0]>140)
            y0=int(math.ceil(outlet));y1=int(min(f['surface_y']-4,g['lower_cy']+g['radius']-9))
            x0=int(cx-.80*half);x1=int(cx+.80*half)+1
            if i<=first_land+3 and y1>y0:
                strip=gold[y0:y1,x0:x1]
                present=np.flatnonzero(strip.sum(axis=1)>=2)
                fronts.append(dict(time=f['time'],elapsed=f['elapsed'],front_y=int(y0+present[-1]) if len(present) else None))
            span=f['surface_y']-outlet
            if f['running'] and .03*period<f['elapsed']<.85*period and span>3*g['neck_width']:
                low=int(outlet+.25*half);high=int(f['surface_y']-half)
                core=gold[low:high,int(cx-.5*half):int(cx+.5*half)+1]
                if core.size:
                    cover=core.mean(axis=1)
                    centers=[]
                    for chunk in np.array_split(gold[low:high,int(cx-1.2*half):int(cx+1.2*half)+1],3):
                        yy,xx=np.where(chunk);centers.append(float(xx.mean()) if len(xx) else None)
                    shape.append(dict(time=f['time'],coverage=float(core.mean()),sparse_run=longest_run(cover<.35),centers=centers))
                if previous is not None and i%5==0:
                    dt=f['time']-previous_row['time'];span=min(span,previous_row['surface_y']-outlet)
                    bands=[]
                    for fraction in (.25,.7):
                        m=displacement(previous,a,cx,outlet+fraction*span,half,min(int(2.5*half),int(.2*span)))
                        if m.get('reliable'):m['speed']=m['dy']/dt
                        bands.append(m)
                    motions.append(dict(time=f['time'],dt=dt,bands=bands))
            if f['running'] and f['transfer']['landed']>0 and span>4:
                lo=max(int(outlet),int(f['surface_y']-half));hi=min(a.shape[0],int(f['surface_y'])+3)
                strip=gold[lo:hi,int(cx-.4*half):int(cx+.4*half)+1]
                if strip.size:contacts.append(dict(time=f['time'],elapsed=f['elapsed'],empty_run=longest_run(strip.mean(axis=1)<.15)))
            if not f['running'] and f['elapsed']<period and pause+.1<f['time']<resume-.1:
                decoded_paused.append(hashlib.sha256(a.tobytes()).hexdigest())
                if last_pause_image is not None:paused_max_delta=max(paused_max_delta,int(np.abs(a.astype(int)-last_pause_image.astype(int)).max()))
                last_pause_image=a
            previous=a;previous_row=f;count+=1
    assert count==len(rows)
    assert max(pts_errors)<.0001
    summary_idx=sorted({min(range(len(rows)),key=lambda i:abs(rows[i]['time']-t)) for t in summary_times})
    board(arm+'-overview.png',[(f"wall {rows[i]['time']:.3f} / e {rows[i]['elapsed']:.3f}",saved[i]) for i in summary_idx],cols=6,thumb=(270,462))
    for name,seq in segments.items():
        ymin=max(0,int(min(outlet,min(rows[i]['surface_y'] for i in seq)))-25)
        ymax=min(r['dimensions'][1],int(max(outlet,max(rows[i]['surface_y'] for i in seq)))+28)
        crop=(int(cx)-65,ymin,int(cx)+65,ymax)
        board(arm+'-'+name+'.png',[(f"{rows[i]['time']:.4f} / e{rows[i]['elapsed']:.3f}",saved[i]) for i in seq],crop=crop,cols=6)
    # A few original 540x924 frames are retained at native scale for visual review.
    for tag,target in [('steady',.5*period),('near-full',.995*period+(r['pause_length'] if period==50 else .5))]:
        idx=min(summary_idx,key=lambda i:abs(rows[i]['time']-target))
        Image.fromarray(saved[idx]).save(OUT/(arm+'-'+tag+'-native.png'))
    good=[m for m in motions if all(b.get('reliable') for b in m['bands'])]
    result=dict(decoded_frames=count,maximum_pts_error=max(pts_errors),video_sha256=r['sha256'],
        events=dict(first_particle_time=rows[first_grain]['time'],first_landing_time=rows[first_land]['time'],last_percent_time=rows[last_percent]['time'],zero_time=rows[zero]['time'],pause_at=pause,resume_at=resume),
        front=fronts,motion_pairs=motions,reliable_motion_pairs=len(good),
        median_upper_speed=float(np.median([m['bands'][0]['speed'] for m in good])) if good else None,
        median_lower_speed=float(np.median([m['bands'][1]['speed'] for m in good])) if good else None,
        reliable_reverse_pairs=[m for m in good if any(b['speed']<0 for b in m['bands'])],
        shape_samples=shape,contact_samples=contacts,decoded_pause_distinct=len(set(decoded_paused)),decoded_pause_max_delta=paused_max_delta,
        raw_pause_distinct=len({rows[i]['image_sha256'] for i in pauses}),
        limitations=['Video decode and continuous-frame analysis, not live video playback.','Lossy video pixels are not byte-identical to captured GL PNGs.','Video colors/settings are the recorded defaults; other colors not audited here.'])
    results[arm]=result
    print(arm,'decoded',count,'PTS max',max(pts_errors),'motion',len(good),'/',len(motions),'speed',result['median_upper_speed'],result['median_lower_speed'],'reverse',len(result['reliable_reverse_pairs']),'pause decoded unique',result['decoded_pause_distinct'],flush=True)
    (OUT/'decoded-analysis.json').write_text(json.dumps(dict(source_digest=EXPECTED,videos=results),indent=2,allow_nan=False),encoding='utf-8')
assert source_digest()==EXPECTED
