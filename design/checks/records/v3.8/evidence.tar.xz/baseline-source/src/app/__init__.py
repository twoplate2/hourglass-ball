"""Shared application modules."""
