"""Bounded independent decode review; no GL or runtime mutation."""
from pathlib import Path
import json, hashlib, math, sys
import av
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'src/tools'))
from release_decision import source_digest
EXPECTED='627e1db34a3818c1398ec99e8d0f61a72600b17ced989192a0e9ee22f8cfd8d0'
assert source_digest()==EXPECTED
BASE=ROOT/'_temp/contact-blend-3.11/release'; OUT=BASE/'motion-review'

def board(name,items,crop=None,cols=6):
    ims=[]
    for label,pixels in items:
        im=Image.fromarray(pixels)
        if crop: im=im.crop(crop)
        ims.append((label,im))
    w=max(im.width for _,im in ims);h=max(im.height for _,im in ims)
    canvas=Image.new('RGB',(cols*w,math.ceil(len(ims)/cols)*(h+22)),'white');d=ImageDraw.Draw(canvas)
    for i,(label,im) in enumerate(ims):
        x=i%cols*w;y=i//cols*(h+22);canvas.paste(im,(x,y+22));d.text((x+2,y+3),label,fill='black')
    canvas.save(OUT/name)

results={}
for arm in ('video-p5','video-p50'):
    folder=BASE/arm;r=json.loads((folder/'audit.json').read_text(encoding='utf-8'));rows=r['frames'];g=r['geometry']
    assert hashlib.sha256((folder/'audit.mp4').read_bytes()).hexdigest()==r['sha256']
    first=next(i for i,f in enumerate(rows) if f['particles']>0)
    land=next(i for i,f in enumerate(rows) if f['transfer']['landed']>1e-8)
    last=next(i for i,f in enumerate(rows) if f['elapsed']>=.99*r['period'])
    zero=next(i for i,f in enumerate(rows) if f['elapsed']>=r['period']-1e-9)
    pause=next(i for i,f in enumerate(rows) if not f['running'] and f['elapsed']<r['period'])
    resume=max(i for i,f in enumerate(rows) if not f['running'] and f['elapsed']<r['period'])+1
    steady=min(range(len(rows)),key=lambda i:abs(rows[i]['elapsed']-.5*r['period']))
    starts={'front':first,'steady':steady,'landing':max(0,land-4),'pause':max(0,pause-4),'resume':max(0,resume-4),'last-percent':max(0,last-4),'zero-tail':max(0,zero-4)}
    segments={k:list(range(s,min(len(rows),s+12))) for k,s in starts.items()}
    selected={i for seq in segments.values() for i in seq}; selected.add(0); selected.add(len(rows)-1)
    saved={};pts_errors=[];count=0
    with av.open(str(folder/'audit.mp4')) as movie:
        for i,vf in enumerate(movie.decode(video=0)):
            if i>=len(rows):raise RuntimeError('extra video frame')
            if i in selected:saved[i]=vf.to_ndarray(format='rgb24')
            pts_errors.append(abs(float(vf.pts*vf.time_base)-rows[i]['time']));count+=1
    assert count==len(rows);assert max(pts_errors)<.0001
    for name,seq in segments.items():
        ymin=max(0,int(min(g['outlet_y'],min(rows[i]['surface_y'] for i in seq)))-25)
        ymax=min(r['dimensions'][1],int(max(g['outlet_y'],max(rows[i]['surface_y'] for i in seq)))+28)
        crop=(int(g['cx'])-130,ymin,int(g['cx'])+130,ymax)
        board(arm+'-'+name+'.png',[(f"{rows[i]['time']:.3f} /e{rows[i]['elapsed']:.3f}",saved[i]) for i in seq],crop)
    for tag,i in [('initial',0),('steady',steady),('last-percent',last),('zero-tail',zero),('final-settled',len(rows)-1)]:
        Image.fromarray(saved[i]).save(OUT/(arm+'-'+tag+'-native.png'))
    results[arm]={'decoded_frames':count,'video_sha256':r['sha256'],'maximum_pts_error':max(pts_errors),'windows':{k:{'indices':seq,'wall_start':rows[seq[0]]['time'],'wall_end':rows[seq[-1]]['time'],'elapsed_start':rows[seq[0]]['elapsed'],'elapsed_end':rows[seq[-1]]['elapsed']} for k,seq in segments.items()}}
    print(arm,count,'frames; selected',len(selected),flush=True)
(OUT/'decode-windows.json').write_text(json.dumps({'source_sha256':EXPECTED,'videos':results},ensure_ascii=False,indent=2),encoding='utf-8')
assert source_digest()==EXPECTED
